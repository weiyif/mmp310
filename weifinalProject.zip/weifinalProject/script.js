var container, stats;
var camera, scene, renderer,particle;
var mouseX = 0, mouseY = 0;
			var windowHalfX = window.innerWidth / 2;
			var windowHalfY = window.innerHeight / 2;

var sun,earth, moon, Mercury,Venus,Mars,Jupiter,Saturn;

var backgroundscene;
var backgroundcamera;


var t = 0;

//var loader = new THREE.TextureLoader();//全景

window.onload = function() {
    var fov = 45;
    var aspectRatio = window.innerWidth / window.innerHeight;
    var near = 1;
    var far = 1000;
    camera = new THREE.PerspectiveCamera(fov, aspectRatio, near, far);
   
    
    //新加的
   //Load the background texture
var texture = THREE.TextureLoader('textures/backgroundstars.jpg');
var backgroundMesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2, 0), new THREE.MeshBasicMaterial({
    map: new THREE.TextureLoader().load('textures/backgroundstars.jpg')
}));

//Setting to make the background and foreground work together
backgroundMesh.material.depthTest = false;
backgroundMesh.material.depthWrite = false;

// Create your background scene
backgroundScene = new THREE.Scene();
backgroundCamera = new THREE.Camera();
backgroundScene.add(backgroundCamera);
backgroundScene.add(backgroundMesh);
    //新加的
                                        
                                        
    var texture = THREE.TextureLoader('textures/stars2.jpg');
var backgroundMesh = new THREE.Mesh(new THREE.PlaneGeometry(2, 2, 0), new THREE.MeshBasicMaterial({
    map: new THREE.TextureLoader().load('textures/stars2.jpg')
}));
    
    //Scene
    scene = new THREE.Scene();
    
    //Renderer
    renderer = new THREE.WebGLRenderer();
    renderer.setSize(window.innerWidth, window.innerHeight);
    document.body.appendChild(renderer.domElement);

    // Create some 3d objects
    var textureLoader = new THREE.TextureLoader();
    var sunTexture =textureLoader.load('textures/sun.gif');
    var sunGeometry = new THREE.SphereGeometry(4, 20, 20);
    var sunMaterial = new THREE.MeshBasicMaterial({
                map: sunTexture
     });
    sun = new THREE.Mesh(sunGeometry, sunMaterial);
    scene.add(sun);
    //////////////////////////////////////////////////////
    
    var earthTexture = textureLoader.load('textures/earth 2.jpeg');
    
    var earthGeometry = new THREE.SphereGeometry(2, 20, 20);
    var earthMaterial = new THREE.MeshStandardMaterial({
        map: earthTexture,
        roughness: 1
    });
    earth = new THREE.Mesh(earthGeometry, earthMaterial);
    sun.add(earth);
    
        
  
 
    
   //earth.orbitSpeed = Math.PI / 9; 
    
//    t +=Math.PI/100*2;
//  
//   //Venus orbit
//   earth.position.x = Math.sin(t*0.2)*25;
//   earth.position.z = Math.cos(t*0.2)*25;
//
//[4:00]  
//var t = 0;
    
    var moonTexture = textureLoader.load('textures/moon.jpg');
    
    var moonGeometry = new THREE.SphereGeometry(1.34, 20, 20);
    var moonMaterial = new THREE.MeshStandardMaterial({
        map: moonTexture,
        roughness: 1
    });
     moon = new THREE.Mesh(moonGeometry, moonMaterial);
    moon.add(earth);
   
//     earth.position.x = Math.sin(t*0.2)*15;
//    earth.position.z = Math.cos(t*0.2)*15;
    
    
    //水星
    var MercuryTexture = textureLoader.load('textures/mercury.jpg');
    
    var MercuryGeometry = new THREE.SphereGeometry(2.45, 30, 20);
    var MercuryMaterial = new THREE.MeshStandardMaterial({
        map: MercuryTexture,
        roughness: 1
    });
    
   
    Mercury = new THREE.Mesh(MercuryGeometry, MercuryMaterial);
    sun.add(earth);
    earth.add(moon);
    sun.add(Mercury);
    
//    Mercury.position.x = 25;
//    moon.position.x = 4;//月亮和地球的距离
    

    
    
//    金星
      var VenusTexture = textureLoader.load('textures/Venus.png');
    
    var VenusGeometry = new THREE.SphereGeometry(2.45, 30, 20);
    var VenusMaterial = new THREE.MeshStandardMaterial({
        map: VenusTexture,
        roughness: 1
    });
    Venus = new THREE.Mesh(VenusGeometry, VenusMaterial);
    sun.add(earth);
    earth.add(moon);
    sun.add(Mercury);
    sun.add(Venus);
    
    
     Venus.position.x = 45;
    moon.position.x = 4;//月亮和地球的距离
    
   
    
    //火星
   var MarsTexture = textureLoader.load('textures/Mars.jpg');
    
    var MarsGeometry = new THREE.SphereGeometry(2.45, 30, 20);
    var MarsMaterial = new THREE.MeshStandardMaterial({
        map: MarsTexture,
        roughness: 1
    });
    
     Mars = new THREE.Mesh(MarsGeometry, MarsMaterial);
    sun.add(earth);
    earth.add(moon);
    sun.add(Mercury);
    sun.add(Venus);
    sun.add(Mars);
    Mars.position.x = 65;
    moon.position.x = 4;//月亮和地球的距离
    //
    
    
    
    
    
    var JupiterTexture = textureLoader.load('textures/Jupiter.jpg');
    
    var JupiterGeometry = new THREE.SphereGeometry(2.45, 30, 20);
    var JupiterMaterial = new THREE.MeshStandardMaterial({
        map: JupiterTexture,
        roughness: 1
    });
    
     Jupiter = new THREE.Mesh( JupiterGeometry, JupiterMaterial);

    sun.add(Jupiter);
    Jupiter.position.x = 105;

    
    
   var SaturnTexture = textureLoader.load('textures/Saturn.jpg');
    
    var SaturnGeometry = new THREE.SphereGeometry(2.45, 30, 20);
    var SaturnMaterial = new THREE.MeshStandardMaterial({
        map: SaturnTexture,
        roughness: 1
    });
    
     Saturn = new THREE.Mesh( SaturnGeometry, SaturnMaterial);
//    sun.add(earth);
//    earth.add(moon);
//    sun.add(Mercury);
//    sun.add(Venus);
//    sun.add(Mars);
    sun.add(Saturn);
    Saturn.position.x = 106;  
   
    
    
    
    
    
    
    
    // Create lights
    var ambient = new THREE.AmbientLight(0xffffff);
    scene.add(ambient);
    
    var light = new THREE.PointLight(0xfffff, 4);
     light.position.z = 10;
    scene.add(light);
    
    camera.position.z = 200;
    
    requestAnimationFrame(animate);
};







document.addEventListener('mousemove', function(event) {
    camera.rotation.y = 0.1 * ((event.offsetX / window.innerWidth) * 2 - 1);
});

function animate() {
    sun.rotation.y += 0.008;
    earth.rotation.y += 0.01;
    moon.rotation.y += 0.001;
    Mercury.rotation.y += 0.01;
    Venus.rotation.y += 0.01;
    Mars.rotation.y += 0.01;
    Jupiter.rotation.y += 0.01;
    Saturn.rotation.y +=0.01;
    
      t +=Math.PI/100*2;
     earth.position.x = Math.sin(t*0.2)*15;
   earth.position.z = Math.cos(t*0.2)*15;
        Mercury.position.x = Math.sin(t*0.4)*25;
        Mercury.position.z = Math.cos(t*0.4)*25;
    Venus.position.x = Math.sin(t*0.6)*45;
    Venus.position.z = Math.cos(t*0.6)*45;
    Mars.position.x = Math.sin(t*0.8)*65;
    Mars.position.z = Math.cos(t*0.8)*65;
    Jupiter.position.x = Math.sin(t*0.5)*105;
    Jupiter.position.z = Math.cos(t*0.5)*105;
    Saturn.position.x = Math.sin(t*0.6)*155;
    Saturn.position.z = Math.cos(t*0.6)*155;
  
    
    
    //新加的
    renderer.autoClear = false;
    renderer.clear();
    renderer.render(backgroundScene, backgroundCamera);
    //新加的
    
    renderer.render(scene, camera);
    requestAnimationFrame(animate);
    
    
}


